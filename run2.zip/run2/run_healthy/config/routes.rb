Rails.application.routes.draw do
  
  get 'order/index'

  get 'gym_pick/index'

  get 'gym_pick/new'

  get 'prac/myresponse'

  get 'home/index'
  post 'order/update/:name/:number/:order/:coordi/:address/:payment/:price/:note' , :to => 'order#update' , constraints: {coordi: /[^\/]+/ , address: /[^\/]+/}
  get 'home/address/:lat/:long'  , :to => 'home#address' , constraints: { lat: /[^\/]+/ , long: /[^\/]+/ }
  get 'shop/index'
  get 'login/login_form'
  get 'shop/new'
  get 'shop/myresponse'
  match ':controller(/:action(/:id))' , :via =>[ :get , :post ]
  root "home#index"


  

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
