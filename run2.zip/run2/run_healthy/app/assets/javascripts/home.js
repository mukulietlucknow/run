$(function(){

	//var msg = 'Sorry, we were unable to get your location.';    
	var lats = "";
	var longs = "";
	
	$('.carousel').carousel({
		interval :2000,
		pause:false,
		wrap:false,
		keyboard:false
	});

	$('#cutomer_location').attr("placeholder" , "mukul");

  if (Modernizr.geolocation) {                                
    navigator.geolocation.getCurrentPosition(success, fail);              
  } 

  function success(position) {                                
    msg = '<h3>Longitude:<br>';                               
    msg += position.coords.longitude + '</h3>'; 
      long = position.coords.longitude;// Add longitude
    msg += '<h3>Latitude:<br>';                               
    msg += position.coords.latitude + '</h3>';    
      lat = position.coords.latitude;// Add latitude
      longs = long;
      lats = lat;
    //  var latlng    = new google.maps.LatLng(lats,longs);
                                   
  }

  function fail(msg) {                                        
    elMap.textContent = msg;                                                               
  }

  $('#locate_customer').on('click' , function(){
    jQuery.ajax({
      url : "/home/address/"+lats+"/"+longs ,
      type : "GET" ,
      dataType : "text" ,
      success : successFn , 
      error : errorFn , 
      complete : function(xhr , status){
        console.log("the request has been complete");
      }

    })
  });

  function successFn(data) {
    $("#customer_location").attr("placeholder" , data);
    $("#locate_customer").text("Order Now");
    $('#locate_customer').on('click' , function(){
    window.location.href = ("http://localhost:3000/shop/index");
  });

  }

  function errorFn(xhr,status,strErr) {
    $("#customer_location").attr("placeholder" , " nope not possible");
  }

  //Sign Up button function

  $('#sign_up_button').on('click' , function(){
    window.location.href = ("http://localhost:3000/login/login_form");
  });

 

});