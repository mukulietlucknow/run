$(function(){

	$("button.add-to-cart").click(function(event){
		event.preventDefault();
		var name = $(this).data("name");
		var detail = $(this).data("detail");
		var price = Number($(this).data("price"));
		addItemToCart(name,detail,price,1);
		updateCart();
		console.log(cart);
		displayCart();
		console.log(totalCost());
	});

	function updateCart(){		
		// console.log(countCart());
		// console.log();
		$("span.badge-cart:nth-child(2)").text(countCart());
		$("#runHealthy-cart .cart-panel-footer span.cart-total").html(totalCost()+"&nbsp;&#x20B9;");
	}

	function displayCart(){
    //var cartArray = listCart();
    var output = "";
    if(cart.length==0){
    	output = "<div class='media'><div class='media-left'><img class='media-object' alt='pic for empty cart' src='/assets/empty_cart.png'></div><div class='media-body' id='empty_cart'><h4 class='media-heading'>Your Cart Is Empty</h4><p>Please Close To Continue</p></div></div>";
    	$("div#check-out.panel-group").attr("hide" , "Yes");
    }else{
    	$("div#check-out").removeAttr("hide");
    	for(var i in cart){
        output += "<tr> <td> <div class='media'> <div class='media-left'> <img class='media-object' alt='isopure_pic' src='/assets/"+cart[i].name+" small.png'> </div> <div class='media-body'> <h4 class='media-heading'>"+cart[i].name+"</h4> <p>"+cart[i].detail+"</p> </div>  </td> <td></div><table class='cart-function' style='text-align: center; font-weight: bold;color: gray;'><tr><td colspan='3'><div class='input-group'><span class='input-group-addon'>"+cart[i].count+"</span><input id='product-price' type='number'  class='form-control' aria-label='Amount (to the nearest dollar)' value="+cart[i].price+" readonly><span class='input-group-addon'>&#x20B9;</span></div></td></tr><tr><td class='add-item' data-name='"+cart[i].name+"'>+</td><td class='subtract-item' data-name='"+cart[i].name+"'>-</td><td class='remove-item' data-name='"+cart[i].name+"'>x</td></tr></table></td></tr>";
    	}	
    }
    
    $("tbody#body-cart").html(output);
    // $("#total-cart").html(totalCost());
    // $("#count-cart").html(countCart());
	}


	$("tbody#body-cart").on("click" , ".subtract-item" , function(event){
		event.preventDefault();
		name = $(this).data("name");
		console.log(name);
		console.log(cart);
		removeFromCart(name);
		displayCart();
		updateCart();

	});


	$("tbody#body-cart").on("click" , ".add-item" , function(event){
		event.preventDefault();
		name = $(this).data("name");
		console.log(name);
		oneItemToCart(name);
		console.log(cart);
		displayCart();
		updateCart();

	});

	$("tbody#body-cart").on("click" , ".remove-item" , function(event){
		event.preventDefault();
		name = $(this).data("name");
		console.log(name);
		removeItemFromCartAll(name);
		console.log(cart);
		displayCart();
		updateCart();

	});

	$("input#order-checkout").on('click' , function(event){
		event.preventDefault();
		var address = $("textarea#delivery_address").val();
		var note = $("textarea#special_notes").val();
		var number = $("input#contact_number").val();
		var order = JSON.stringify(cart);
		var price = totalCost();
		jQuery.ajax({
	      url : "/order/update/"+"mukul"+"/"+number+"/"+order+"/"+"1233476737"+"/"+address+"/"+"COD"+"/"+price+"/"+note ,
	      type : "Post" ,
	      dataType : "text" ,
	      success : SuccessFn , 
	      error : ErrorFn , 
	      complete : function(xhr , status){
	        console.log("the request has been complete");
	      }
    	});
	});

	function SuccessFn(){
		console.log("done successfully");
	}


	function ErrorFn(){
		console.log("done not successfully");
	}






	$("button#option_opted").click(function(event){
		event.preventDefault();
		var value = $("div#Isopure-lean-options div#isopure_shake label input").is(":checked");
		console.log(value);
		displayCart2();
	});

	function displayCart2(){
    //var cartArray = listCart();
    var output = "";
    if(cart.length==0){
    	output = "<div class='media'><div class='media-left'><img class='media-object' alt='pic for empty cart' src='/assets/empty_cart.png'></div><div class='media-body' id='empty_cart'><h4 class='media-heading'>Your Cart Is Empty</h4><p>Please Close To Continue</p></div></div>";
    	$("div#check-out.panel-group").attr("hide" , "Yes");
    }else{
    	$("div#check-out").removeAttr("hide");
    	for(var i in cart){
    		var product = cart[i].name+' small.png';
    		output += "<tr> <td> <div class='media'> <div class='media-left'> <img class='media-object' alt='isopure_pic' src='/assets/"+product+"'> </div> <div class='media-body'> <h4 class='media-heading'>"+cart[i].name+"</h4> <p>"+cart[i].detail+"</p> </div>  </td> <td></div><table class='cart-function' style='text-align: center; font-weight: bold;color: gray;'><tr><td colspan='3'><div class='input-group'><span class='input-group-addon'>"+cart[i].count+"</span><input id='product-price' type='number'  class='form-control' aria-label='Amount (to the nearest dollar)' value="+cart[i].price+" readonly><span class='input-group-addon'>&#x20B9;</span></div></td></tr><tr><td class='add-item' data-name='"+cart[i].name+"'>+</td><td class='subtract-item' data-name='"+cart[i].name+"'>-</td><td class='remove-item' data-name='"+cart[i].name+"'>x</td></tr></table></td></tr>";
    	}	
    }
    $("tbody#body-cart").html(output);
    // $("#total-cart").html(totalCost());
    // $("#count-cart").html(countCart());
	}


	



	//***********************cart*Functions************//



	var cart = [];

	

	

	//object for item quality
	var Item = function(name ,detail, price , count){
	    this.name = name;
	    this.detail = detail;
	    this.price = price;
	    this.count = count ;
	}

	
	//funtion for making item quantity what customer want

	function setItemCount(name , count){
		for(var i in cart){
			if(cart[i].name == name){
				cart[i].count=count;
				break;
			}
		}
	}

	

	// funtion to add item in cart

	function addItemToCart(name ,detail, price , count){
	    for(var i in cart){
	        if(cart[i].name === name){
	            cart[i].count += count;
	            return;
	        }
	    }
	    cart.push(new Item(name ,detail ,  price , count));
	}


	//this function will remove item from cart one by one
	function removeFromCart(name){
	    for(var i in cart){
	            if (cart[i].name === name){
	                cart[i].count--;
	                if (cart[i].count===0){
	                    cart.splice(i,1);
	        		}
	        	break;
	       		}
	        
	    }
	}

	function oneItemToCart(name){
	    for(var i in cart){
	            if (cart[i].name === name){
	                cart[i].count++;
	            break;
	       		}
	        
	    }
	}


	//this function will remove one item at once

	function removeItemFromCartAll(name){
	    for(var i in cart){
	        if(cart[i].name===name){
	            cart.splice(i,1);
	        }
	    }
	}


	//it will make cart empty....

	function clearCart(){
	    cart = [];
	}


	//it will count all number of item present in tha cart

	function countCart(){
	    var totalItem = 0;
	    for(var i in cart){
	        totalItem += cart[i].count;
	    }
	    return totalItem;
     
	}

	//it will sum up all item's prices

	function totalCost(){
	    var cost = 0 ;
	    for(var i in cart){
	        cost += cart[i].price*(cart[i].count);
	    }
	    return cost;
	}

	// function for making copy for the items present in the cart.
	function listCart(){
	    var cartCopy = [];
	    for(var i in cart){
	        var item = cart[i];
	        cartItem = {};
	        for(var p in item){
	            cartItem[p] = item[p];
	        }
	        cartItem.total = cartItem.count * cartItem.price;
	        cartCopy.push(cartItem);
	    }
	    return cartCopy; 
	}


	// save cart in the memory
	function saveCart(){
	    localStorage.setItem("RunHealthyCart" , JSON.stringify(cart));
	}

	// load cart from local storage

	function loadCart(){
	    cart = JSON.parse(localStorage.getItem("RunHealthyCart"));
	}

	function notifyCart(){
		var output = "";
    	if(cart.length==0){
	    	output = "<div class='media'><div class='media-left'><img class='media-object' alt='pic for empty cart' src='/assets/empty_cart.png'></div><div class='media-body' id='empty_cart'><h4 class='media-heading'>Your Cart Is Empty</h4><p>Please Close To Continue</p></div></div>";
	    	
	    }

	    $("tbody#body-cart").html(output);
	    updateCart();

	}

	notifyCart();
	// cart.push(new Item("mukul" , 100 , 1));
	// setItemCount("mukul",5);
	//addItemToCart("kumar" ,"jkjkj", 100,2);
	// removeFromCart("mukul")
	// //removeItemFromCartAll("kumar")
	// //clearCart();
	// num = totalCost();
	// console.log(cart);
	// console.log(num);
	// console.log(listCart());
	// saveCart();




});