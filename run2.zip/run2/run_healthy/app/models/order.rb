class Order < ApplicationRecord
	after_update :reload_page


	def reload_page
		puts ("mukul")
		render('order')
	end
end
