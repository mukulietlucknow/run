class GymPickController < ApplicationController
	layout 'gym_pick_layout'
  def index
  end

  def new
  end
end
