class HomeController < ApplicationController
	layout 'application'
	require 'net/http'
	require 'openssl'
	require 'open-uri'
	require 'json'
	
  def index
  end

  def address
  	url = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+params[:lat]+","+params[:long]+"&location_type=APPROXIMATE&key=AIzaSyCg_ClcvqO1vqS5YaVRTgpcrRN0r2x_QI8"
	uri = URI(url)
	http = Net::HTTP.new(uri.host, uri.port)
	http.use_ssl = true
	http.verify_mode = OpenSSL::SSL::VERIFY_NONE
	request = Net::HTTP::Get.new(uri.request_uri)
	response = http.request(request)
	@data = response.body
	json = JSON(@data)
	address = json['results'][0]['formatted_address']
  	render plain: address 
  end
end
