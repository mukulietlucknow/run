class LoginController < ApplicationController
	layout 'application_login'
	
  def login_form
    render("login_form")
  end

  def create
  	@user = User.new(user_params)
  	if @user.save
  		redirect_to(:action => "index" , :controller => "home")
  	else
  		render("login_form")
  	end
  end

  def attempt_login
    if params[:email].present? && params[:password].present?
      found_user = User.where(:email => params[:email]).first
      if found_user
        authorized_user = found_user.authenticate(params[:password])
      end
    end
    if authorized_user
      session[:user_name] = found_user.first_name
      puts session[:user_name]
      redirect_to(:action=>"index" , :controller => "home")
    else
      render("login_form")
    end

  end

  private
  def user_params
  	params.require(:user_data).permit(:first_name,:last_name,:email,:password,:user_detail)
  end
end
