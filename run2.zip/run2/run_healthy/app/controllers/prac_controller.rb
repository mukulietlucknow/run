class PracController < ApplicationController
  def myresponse
  end
end
