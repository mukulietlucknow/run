class OrderController < ApplicationController
  require 'json'
	protect_from_forgery with: :null_session
	layout 'order'
  def index
  	@orders = Order.all
  end

  def update
  	@order  = Order.create(:customer_name => params[:name] , :contact_number => params[:number] , :order => params[:order] , :coordinate => params[:coordi] , :address => params[:address] , :payment_mode => params[:payment] , :Price => params[:price] , :note => params[:note] )
  	

  	
  end


end
