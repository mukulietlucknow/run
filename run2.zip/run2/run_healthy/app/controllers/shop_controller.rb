class ShopController < ApplicationController

layout 'application_shop'

  def index
  end

  def edit
  end

  def new
  end
end
