module GymPickHelper
end
