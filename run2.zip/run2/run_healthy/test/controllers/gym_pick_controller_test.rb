require 'test_helper'

class GymPickControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get gym_pick_index_url
    assert_response :success
  end

  test "should get new" do
    get gym_pick_new_url
    assert_response :success
  end

end
