require 'test_helper'

class PracControllerTest < ActionDispatch::IntegrationTest
  test "should get myresponse" do
    get prac_myresponse_url
    assert_response :success
  end

end
