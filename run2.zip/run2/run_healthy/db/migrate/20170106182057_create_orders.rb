class CreateOrders < ActiveRecord::Migration[5.0]
  def up
    create_table :orders do |t|
      t.string "customer_name" 
      t.string "contact_number"
      t.text "order"
      t.string "coordinate"
      t.string "address"
      t.string "fullfilled?" , :default => "No"
      t.string "payment_mode"
      t.string "order_status" , :default => "Active"
      t.string "Price"
      t.text "note"
      t.timestamps
    end
  end

  def down
  	drop_table :orders
  end
end
